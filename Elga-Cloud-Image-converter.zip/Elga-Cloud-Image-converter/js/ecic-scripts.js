function previewImage(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('preview-img');
        output.src = reader.result;
        document.getElementById('image-preview').style.display = 'block';
    };
    reader.readAsDataURL(event.target.files[0]);
}

function convertImage() {
    var inputFile = document.getElementById('image_file');
    var outputFormat = document.getElementById('output_format').value;

    if (inputFile.files.length > 0) {
        var file = inputFile.files[0];

        document.getElementById('conversion-loader').style.display = 'block';

        var reader = new FileReader();
        reader.onload = function(e) {
            var img = new Image();
            img.src = e.target.result;

            img.onload = function() {
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                canvas.width = img.width;
                canvas.height = img.height;

                ctx.drawImage(img, 0, 0);

                var convertedImage = canvas.toDataURL('image/' + outputFormat);

                document.getElementById('conversion-loader').style.display = 'none';

                var downloadButton = document.getElementById('download-button');
                downloadButton.innerHTML = '<a href="' + convertedImage + '" download="converted_image.' + outputFormat + '" class="download-link">Download Converted Image</a>';
            }
        }
        reader.readAsDataURL(file);
    }
}

function resetForm() {
    document.getElementById('image-converter-form').reset();
    document.getElementById('conversion-result').innerHTML = '';
    document.getElementById('download-button').innerHTML = '';
    document.getElementById('conversion-messages').innerHTML = '';
    document.getElementById('image-preview').style.display = 'none';
}
