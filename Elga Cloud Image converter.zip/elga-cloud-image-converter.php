<?php
/*
Plugin Name: Elga Cloud Image Converter
Plugin URI: https://elgacloud.com/
Description: A simple image converter plugin developed by Elga Cloud that allows users to convert images to different formats.
Version: 1.0
Author: Elga Cloud
Author URI: https://elgacloud.com/
License: GPL2
Requires PHP: 7.4
Requires WP: 6.6.1
*/

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue styles and scripts
function ecic_enqueue_scripts() {
    wp_enqueue_style('ecic-styles', plugin_dir_url(__FILE__) . 'css/ecic-styles.css');
    wp_enqueue_script('ecic-scripts', plugin_dir_url(__FILE__) . 'js/ecic-scripts.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'ecic_enqueue_scripts');

// Shortcode to display the image converter form
function ecic_image_converter_shortcode() {
    ob_start();
    ?>

    <div id="conversion-container">
        <h2 class="conversion-title">Image Converter</h2>
        <p class="conversion-description">Select an image file and choose the desired output format to convert it.</p>
        <form id="image-converter-form" enctype="multipart/form-data">
            <div class="form-group">
                <label for="image_file" class="file-label">Select an image file:</label>
                <input type="file" name="image_file" id="image_file" accept=".bmp, .dds, .dib, .djvu, .gif, .heic, .icns, .ico, .jp2, .jpe, .jpeg, .jpg, .png, .psd, .raw, .svg, .tiff, .tga, .webp" class="file-input" onchange="previewImage(event)">
                <span class="file-types">Supported types: PNG, JPG, GIF, BMP, TIFF, ICO, ICO, SVG, WEBP</span>
            </div>

            <!-- Image Preview -->
            <div id="image-preview" class="form-group" style="display:none;">
                <img id="preview-img" src="" alt="Image Preview" style="max-width:100%; height:auto;">
            </div>

            <div class="form-group">
                <label for="output_format" class="select-label">Output format:</label>
                <select name="output_format" id="output_format" class="select-input">
                    <option value="png">PNG</option>
                    <option value="jpeg">JPEG</option>
                    <option value="gif">GIF</option>
                    <option value="bmp">BMP</option>
                    <option value="tiff">TIFF</option>
                    <option value="ico">ICO</option>
                    <option value="svg">SVG</option>
                    <option value="webp">WEBP</option>
                </select>
            </div>
            <div class="button-container">
                <button type="button" onclick="convertImage()" class="convert-button">Convert</button>
                <button type="button" onclick="resetForm()" class="reset-button">Reset</button>
            </div>
        </form>

        <div id="conversion-loader" style="display: none;">
            <div class="loader"></div>
            <p class="conversion-message">Converting...</p>
        </div>
        <div id="conversion-result"></div>
        <div id="download-button"></div>
        <div id="conversion-messages"></div>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('elgacloud_image_converter', 'ecic_image_converter_shortcode');

// Add admin menu item
function ecic_admin_menu() {
    add_menu_page(
        'Elga Cloud Image Converter',
        'Elga Cloud Image Converter',
        'manage_options',
        'elga-cloud-image-converter',
        'ecic_admin_page',
        'dashicons-format-image',
        76
    );
}
add_action('admin_menu', 'ecic_admin_menu');

// Display admin page content
function ecic_admin_page() {
    ?>
    <div class="wrap">
        <h1>Elga Cloud Image Converter</h1>
        <p>Welcome to the Elga Cloud Image Converter plugin. Use the shortcode <code>[elgacloud_image_converter]</code> to display the image converter form on your site.</p>
    </div>
    <?php
}

// Ensure the plugin is activated properly
function ecic_activate_plugin() {
    // Actions to perform once on plugin activation
}
register_activation_hook(__FILE__, 'ecic_activate_plugin');
